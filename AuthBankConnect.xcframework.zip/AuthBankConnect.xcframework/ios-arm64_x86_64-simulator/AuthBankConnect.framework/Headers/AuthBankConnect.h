//
//  AuthBankConnect.h
//  AuthBankConnect
//
//  Created by Amarildo Joao Custodio Lucas on 20/06/21.
//

#import <Foundation/Foundation.h>

//! Project version number for AuthBankConnect.
FOUNDATION_EXPORT double AuthBankConnectVersionNumber;

//! Project version string for AuthBankConnect.
FOUNDATION_EXPORT const unsigned char AuthBankConnectVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <AuthBankConnect/PublicHeader.h>


